﻿namespace IIITS.Training.RepoInterfaces
{
    public class Class1
    {

    }
}
