﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIITS.Training.DataEntities.DemoModel
{
	public class DemoModelEntity
	{
		public string? DropDown { get; set; }
		public string? TextField { get; set; }
		public int Number { get; set; }
	}
}
